
public class TestPassword {
public static void main(String[] args) {
	
}

}
